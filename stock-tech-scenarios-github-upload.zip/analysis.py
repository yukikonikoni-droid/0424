"""Technical scenario scoring from OHLCV (rule-based). Not investment advice."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class Scenario:
    key: str
    title_ja: str
    summary_ja: str
    probability_pct: float
    reasons_ja: list[str]


def _ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def _macd(close: pd.Series) -> tuple[pd.Series, pd.Series, pd.Series]:
    ema12 = _ema(close, 12)
    ema26 = _ema(close, 26)
    line = ema12 - ema26
    signal = _ema(line, 9)
    hist = line - signal
    return line, signal, hist


def _bb_width(close: pd.Series, window: int = 20, n_std: float = 2.0) -> pd.Series:
    ma = close.rolling(window, min_periods=window).mean()
    std = close.rolling(window, min_periods=window).std()
    upper = ma + n_std * std
    lower = ma - n_std * std
    return (upper - lower) / ma.replace(0, np.nan)


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    c = out["Close"]
    out["SMA5"] = c.rolling(5, min_periods=5).mean()
    out["SMA20"] = c.rolling(20, min_periods=20).mean()
    out["SMA30"] = c.rolling(30, min_periods=20).mean()
    out["SMA60"] = c.rolling(60, min_periods=20).mean()
    out["RSI14"] = _rsi(c, 14)
    _, _, hist = _macd(c)
    out["MACD_hist"] = hist
    out["BB_width"] = _bb_width(c, 20, 2.0)
    out["Vol_ma20"] = out["Volume"].rolling(20, min_periods=20).mean()
    return out


def _last(row: pd.Series, name: str) -> float:
    v = row[name]
    return float(v) if pd.notna(v) else float("nan")


def _softmax(scores: dict[str, float], temperature: float = 1.15) -> dict[str, float]:
    keys = list(scores.keys())
    arr = np.array([scores[k] for k in keys], dtype=float)
    arr = np.maximum(arr, 1e-6)
    arr = arr ** (1.0 / temperature)
    s = arr.sum()
    if s <= 0 or not np.isfinite(s):
        n = len(keys)
        return {k: 1.0 / n for k in keys}
    probs = arr / s
    return {k: float(p) for k, p in zip(keys, probs)}


def _round_probs(probs: dict[str, float], digits: int = 1) -> dict[str, float]:
    keys = list(probs.keys())
    raw = [round(probs[k] * 100, digits) for k in keys]
    diff = 100.0 - sum(raw)
    if keys and abs(diff) >= 10 ** (-digits):
        idx = int(np.argmax(raw))
        raw[idx] = round(raw[idx] + diff, digits)
    return {k: raw[i] for i, k in enumerate(keys)}


def _safe_float(v: Any) -> float | None:
    if v is None:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if not np.isfinite(f):
        return None
    return f


def fetch_fundamentals(ticker: str) -> dict[str, Any]:
    import yfinance as yf

    try:
        info = yf.Ticker(ticker).info or {}
    except Exception:
        info = {}
    pe = _safe_float(info.get("trailingPE") or info.get("forwardPE"))
    pb = _safe_float(info.get("priceToBook"))
    roe = _safe_float(info.get("returnOnEquity"))
    debt_to_equity = _safe_float(info.get("debtToEquity"))
    rev_growth = _safe_float(info.get("revenueGrowth"))
    earn_growth = _safe_float(info.get("earningsGrowth"))
    current_ratio = _safe_float(info.get("currentRatio"))
    op_margin = _safe_float(info.get("operatingMargins"))
    sector = info.get("sector")
    name = info.get("longName") or info.get("shortName")

    metrics = {
        "trailing_pe": pe,
        "price_to_book": pb,
        "roe": roe,
        "debt_to_equity": debt_to_equity,
        "revenue_growth": rev_growth,
        "earnings_growth": earn_growth,
        "current_ratio": current_ratio,
        "operating_margin": op_margin,
        "sector": sector,
        "name": name,
    }

    bull = 0.0
    bear = 0.0
    reasons_bull: list[str] = []
    reasons_bear: list[str] = []

    if pe is not None:
        if pe < 12:
            bull += 1.2
            reasons_bull.append(f"PERが{pe:.1f}と低めで、バリュエーション面の下支えが期待されます。")
        elif pe > 35:
            bear += 1.2
            reasons_bear.append(f"PERが{pe:.1f}と高めで、割高感による調整リスクがあります。")

    if pb is not None:
        if pb < 1.2:
            bull += 0.8
            reasons_bull.append(f"PBRが{pb:.2f}で資産価値対比では割安圏に近い水準です。")
        elif pb > 4.0:
            bear += 0.8
            reasons_bear.append(f"PBRが{pb:.2f}と高く、期待先行が剥落すると値幅が出やすいです。")

    if roe is not None:
        if roe > 0.12:
            bull += 1.0
            reasons_bull.append(f"ROEが{roe*100:.1f}%と高く、資本効率の良さが評価されやすいです。")
        elif roe < 0.05:
            bear += 0.8
            reasons_bear.append(f"ROEが{roe*100:.1f}%と低く、収益効率面が重しになり得ます。")

    if rev_growth is not None:
        if rev_growth > 0.08:
            bull += 1.1
            reasons_bull.append(f"売上成長率が{rev_growth*100:.1f}%で、成長期待が株価を支えやすいです。")
        elif rev_growth < -0.03:
            bear += 1.1
            reasons_bear.append(f"売上成長率が{rev_growth*100:.1f}%で、業績モメンタムが弱含みです。")

    if earn_growth is not None:
        if earn_growth > 0.08:
            bull += 1.0
            reasons_bull.append(f"利益成長率が{earn_growth*100:.1f}%で、先行き改善期待があります。")
        elif earn_growth < -0.05:
            bear += 1.0
            reasons_bear.append(f"利益成長率が{earn_growth*100:.1f}%で、下方圧力に注意が必要です。")

    if debt_to_equity is not None:
        if debt_to_equity < 50:
            bull += 0.7
            reasons_bull.append(f"D/Eレシオが{debt_to_equity:.1f}で、財務レバレッジは比較的抑制的です。")
        elif debt_to_equity > 200:
            bear += 0.9
            reasons_bear.append(f"D/Eレシオが{debt_to_equity:.1f}と高く、金利環境に左右されやすいです。")

    if current_ratio is not None and current_ratio < 1.0:
        bear += 0.6
        reasons_bear.append(f"流動比率が{current_ratio:.2f}で、短期の資金余力には注意が必要です。")

    if op_margin is not None and op_margin > 0.15:
        bull += 0.5
        reasons_bull.append(f"営業利益率が{op_margin*100:.1f}%で、収益体質は相対的に堅調です。")

    quality_score = bull - bear
    stance = "中立"
    if quality_score > 1.5:
        stance = "やや強気"
    elif quality_score < -1.5:
        stance = "やや弱気"

    return {
        "metrics": metrics,
        "bull_score": bull,
        "bear_score": bear,
        "quality_score": quality_score,
        "stance": stance,
        "reasons_bull": reasons_bull,
        "reasons_bear": reasons_bear,
        "available": len(reasons_bull) + len(reasons_bear) > 0,
    }


def build_scenarios(df: pd.DataFrame, fundamentals: dict[str, Any] | None = None) -> tuple[list[Scenario], dict[str, Any]]:
    if len(df) < 20:
        raise ValueError("データが不足しています（短期分析でも最低20本程度の足が必要です）。")

    d = add_indicators(df).dropna(subset=["SMA5", "SMA20", "RSI14", "MACD_hist", "BB_width", "Vol_ma20"])
    if len(d) < 3:
        raise ValueError("指標計算後のデータが不足しています。期間を少し長くしてください。")

    last = d.iloc[-1]
    prev = d.iloc[-2]

    close = _last(last, "Close")
    sma5 = _last(last, "SMA5")
    sma20 = _last(last, "SMA20")
    sma30 = _last(last, "SMA30")
    sma60 = _last(last, "SMA60")
    long_name = "SMA60" if np.isfinite(sma60) else "SMA30"
    long_ma = sma60 if long_name == "SMA60" else sma30

    rsi = _last(last, "RSI14")
    macd_h = _last(last, "MACD_hist")
    macd_h_prev = _last(prev, "MACD_hist")
    bbw = _last(last, "BB_width")
    bbw_ma = float(d["BB_width"].tail(20).mean())
    vol = _last(last, "Volume")
    vol_ma = _last(last, "Vol_ma20")

    ret5 = (close / float(d["Close"].iloc[-6]) - 1.0) * 100 if len(d) >= 6 else 0.0
    recent_range = ((d["High"].tail(5).max() - d["Low"].tail(5).min()) / close * 100) if close else 0.0

    sma_alignment_bull = close > sma20 > long_ma
    sma_alignment_bear = close < sma20 < long_ma
    macd_hist_rising = macd_h > macd_h_prev
    volume_ratio = (vol / vol_ma) if vol_ma and np.isfinite(vol_ma) and vol_ma > 0 else 1.0
    bbw_vs_avg = (bbw / bbw_ma) if bbw_ma and np.isfinite(bbw_ma) and bbw_ma > 0 else 1.0

    ctx: dict[str, Any] = {
        "close": close,
        "sma5": sma5,
        "sma20": sma20,
        "sma30": sma30,
        "sma60": sma60,
        "long_ma_name": long_name,
        "long_ma_value": long_ma,
        "sma_alignment_bull": sma_alignment_bull,
        "sma_alignment_bear": sma_alignment_bear,
        "rsi": rsi,
        "macd_hist": macd_h,
        "macd_hist_rising": macd_hist_rising,
        "volume_ratio": volume_ratio,
        "bbw_vs_avg": bbw_vs_avg,
        "ret5_pct": ret5,
        "recent_range_pct": recent_range,
    }

    s_up = s_pull = s_range = s_down = s_vol = 0.0

    if sma_alignment_bull and 45 <= rsi <= 68:
        s_up += 2.2
    if close > sma20 and macd_h > 0 and macd_hist_rising:
        s_up += 1.4
    if volume_ratio > 1.15 and close >= sma5:
        s_up += 0.8
    if ret5 > 3 and rsi < 72:
        s_up += 0.6

    if rsi > 70 or (close > sma20 * 1.04 and ret5 > 4):
        s_pull += 2.0
    if rsi > 65 and macd_h < macd_h_prev:
        s_pull += 1.2
    if close > sma20 and rsi > 60:
        s_pull += 0.5

    if 44 <= rsi <= 56 and abs(close / sma20 - 1) < 0.02:
        s_range += 2.0
    if bbw_vs_avg < 0.85:
        s_range += 1.2
    if abs(ret5) < 2:
        s_range += 0.7

    if sma_alignment_bear and rsi < 52:
        s_down += 2.2
    if close < sma20 and macd_h < 0:
        s_down += 1.3
    if rsi < 38:
        s_down += 1.0
    if ret5 < -3:
        s_down += 0.8

    if bbw_vs_avg > 1.2 or recent_range > 5:
        s_vol += 1.8
    if (macd_h > 0 and rsi < 45) or (macd_h < 0 and rsi > 55):
        s_vol += 1.2
    if 58 <= rsi <= 62 and abs(close / sma20 - 1) < 0.015:
        s_vol += 0.5

    fundamental_used = False
    if fundamentals and fundamentals.get("available"):
        quality = float(fundamentals.get("quality_score", 0.0))
        tilt = min(abs(quality), 3.0) * 0.35
        fundamental_used = True
        if quality > 0:
            s_up += 0.6 + tilt
            s_down = max(0.15, s_down - (0.35 + tilt * 0.5))
            s_pull += 0.12
        elif quality < 0:
            s_down += 0.6 + tilt
            s_up = max(0.15, s_up - (0.35 + tilt * 0.5))
            s_pull += 0.15
        else:
            s_range += 0.2

    scores = {
        "uptrend": max(s_up, 0.35),
        "pullback": max(s_pull, 0.35),
        "range": max(s_range, 0.35),
        "downtrend": max(s_down, 0.35),
        "volatile": max(s_vol, 0.35),
    }
    probs = _round_probs(_softmax(scores))

    trend_label = f"{long_name}（長めの平均）"

    reasons_up: list[str] = []
    if sma_alignment_bull:
        reasons_up.append(f"終値がSMA20と{trend_label}の上にあり、上昇トレンド配置です。")
    if macd_h > 0 and macd_hist_rising:
        reasons_up.append("MACDヒストグラムがプラスで拡大しており、モメンタム継続を示唆します。")
    if 45 <= rsi <= 68:
        reasons_up.append(f"RSIが{rsi:.1f}付近で、極端な過熱域手前のゾーンにあります。")
    if volume_ratio > 1.1:
        reasons_up.append("出来高が20日平均を上回り、関心の高まりが見えます。")
    if not reasons_up:
        reasons_up.append("上値を支持する要素はあるものの、他シナリオと拮抗しています。")
    if fundamental_used and fundamentals.get("quality_score", 0.0) > 0:
        reasons_up.append("ファンダメンタルの総合評価が強めで、中期の買い安心感が下支えになりやすいです。")

    reasons_pull: list[str] = []
    if rsi > 65:
        reasons_pull.append(f"RSIが{rsi:.1f}と高めで、短期的な利確・調整が出やすい水準です。")
    if close > sma20 * 1.02:
        reasons_pull.append("価格が中期平均から離れており、平均への回帰（押し）が起きやすい状況です。")
    if macd_h < macd_h_prev and macd_h > 0:
        reasons_pull.append("MACDの勢いが弱まりつつあり、上昇ペースの鈍化シグナルになり得ます。")
    if not reasons_pull:
        reasons_pull.append("急伸後でなくても、ノイズで小幅反落はよく起こります。")

    reasons_range: list[str] = []
    if 44 <= rsi <= 56:
        reasons_range.append(f"RSIが{rsi:.1f}付近の中立圏で、方向感が出にくい状態です。")
    if bbw_vs_avg < 0.9:
        reasons_range.append("ボリンジャーバンド幅が平均より狭く、変動率低下（もみ合い）が続きやすいです。")
    if abs(ret5) < 2:
        reasons_range.append("直近5営業日の値動きが小さく、レンジ内の慣性があります。")
    if not reasons_range:
        reasons_range.append("明確なブレイクアウトがなく、売り買いが拮抗している可能性があります。")

    reasons_down: list[str] = []
    if sma_alignment_bear:
        reasons_down.append(f"終値がSMA20と{trend_label}の下にあり、下降トレンド配置です。")
    if rsi < 45:
        reasons_down.append(f"RSIが{rsi:.1f}と弱めで、売り優勢のモメンタムが残りやすいです。")
    if macd_h < 0:
        reasons_down.append("MACDヒストグラムがマイナス圏で、下方向の勢いが継続しやすいです。")
    if ret5 < -2:
        reasons_down.append("直近の下げ幅が大きく、弱気な追随売りが出るリスクがあります。")
    if not reasons_down:
        reasons_down.append("下降トレンドの決定打は弱いものの、悪材料で急変する余地は常にあります。")
    if fundamental_used and fundamentals.get("quality_score", 0.0) < 0:
        reasons_down.append("ファンダメンタルの弱さが意識されると、戻り売りが出やすい地合いです。")

    reasons_vol: list[str] = []
    if bbw_vs_avg > 1.15:
        reasons_vol.append("ボラティリティが平均より高く、大きめの上下ヒゲやギャップが出やすいです。")
    if (macd_h > 0 and rsi < 45) or (macd_h < 0 and rsi > 55):
        reasons_vol.append("モメンタム系とオシレーターの読みが食い違い、方向の分岐が読みにくいです。")
    if recent_range > 4:
        reasons_vol.append("直近の高値-安値レンジが広く、翌日も不安定な展開があり得ます。")
    if not reasons_vol:
        reasons_vol.append("イベントや市場全体のリスクオフで、想定外の変動が起きる可能性は常にあります。")

    scenarios = [
        Scenario("uptrend", "上昇継続（トレンドフォロー）", "前日の流れを引き継ぎ、高値更新や移動平均上での推移が続く想定です。", probs["uptrend"], reasons_up),
        Scenario("pullback", "調整・押し目", "一時的な利確や過熱の解消で、前日比ではマイナス〜小反落になりやすい想定です。", probs["pullback"], reasons_pull),
        Scenario("range", "横ばい・レンジ", "明確な方向が出ず、前日終値近辺を中心に狭い範囲で推移する想定です。", probs["range"], reasons_range),
        Scenario("downtrend", "下落・弱気継続", "移動平均やモメンタムが下向きのまま、安値更新や陰線が続く想定です。", probs["downtrend"], reasons_down),
        Scenario("volatile", "ボラティリティ拡大・終値の方向が読みにくい", "大きな上下動やギャップの可能性はあるが、終値位置は読みにくい想定です。", probs["volatile"], reasons_vol),
    ]
    if fundamental_used:
        ctx["fundamental_used"] = True
        ctx["fundamental_stance"] = fundamentals.get("stance", "中立")
        ctx["fundamental_quality_score"] = float(fundamentals.get("quality_score", 0.0))
        ctx["fundamental_reasons_bull"] = fundamentals.get("reasons_bull", [])
        ctx["fundamental_reasons_bear"] = fundamentals.get("reasons_bear", [])
    else:
        ctx["fundamental_used"] = False
    scenarios.sort(key=lambda x: x.probability_pct, reverse=True)
    return scenarios, ctx


def fetch_ohlcv(ticker: str, period: str = "1y") -> pd.DataFrame:
    import yfinance as yf

    t = yf.Ticker(ticker)
    attempts: list[pd.DataFrame | None] = []

    try:
        attempts.append(t.history(period=period, auto_adjust=True))
    except Exception:
        attempts.append(None)

    try:
        attempts.append(t.history(period=period, auto_adjust=False))
    except Exception:
        attempts.append(None)

    try:
        attempts.append(
            yf.download(
                tickers=ticker,
                period=period,
                interval="1d",
                auto_adjust=True,
                progress=False,
                threads=False,
            )
        )
    except Exception:
        attempts.append(None)

    df: pd.DataFrame | None = None
    for cand in attempts:
        if cand is None or cand.empty:
            continue
        df = cand.copy()
        break

    if df is None or df.empty:
        raise ValueError(
            f"データを取得できませんでした: {ticker}。"
            " ティッカー形式（例: 7203.T / AAPL）とネットワーク接続を確認してください。"
        )

    if isinstance(df.columns, pd.MultiIndex):
        # yf.download can return MultiIndex columns like ('Close', 'AAPL')
        df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]

    df = df.rename(columns=str.title)
    need = ["Open", "High", "Low", "Close", "Volume"]
    if not set(need).issubset(set(df.columns)):
        raise ValueError("取得データの形式が想定と異なります。")
    out = df[need].dropna(subset=["Open", "High", "Low", "Close"])
    if out.empty:
        raise ValueError(f"価格データが空です: {ticker}")
    return out
