﻿# Stock Technical + Fundamental Scenarios

個別銘柄のチャートとファンダメンタル情報をもとに、翌営業日の値動きを5シナリオで可視化する Streamlit アプリです。

## 主な機能

- ローソク足チャート + 出来高 + 移動平均線（SMA5/20/30/60）
- テクニカル分析による翌営業日シナリオ（5パターン）
- ファンダメンタル指標（PER/PBR/ROE/成長率/財務）を加味した総合判断
- プレゼンテーション風ダッシュボード表示（棒グラフ・ドーナツチャート・解説カード）

## 必要環境

- Python 3.10+
- インターネット接続（Yahoo Finance からデータ取得）

## セットアップ

```bash
pip install -r requirements.txt
```

## 起動

```bash
streamlit run app.py
```

Windows の場合は `run.bat` からも起動できます。

## ティッカー入力例

- 日本株: `7203.T` / `6758.T`
- 米国株: `AAPL` / `MSFT`
- 指数: `^N225` / `^GSPC`

## ファイル構成

- `app.py`: Streamlit UI / 可視化
- `analysis.py`: データ取得・指標計算・シナリオ推定ロジック
- `requirements.txt`: 依存ライブラリ
- `run.bat`: Windows 起動補助

## 免責

本アプリは教育・情報整理目的であり、投資助言ではありません。
