# -*- coding: utf-8 -*-
"""Streamlit: next-day scenario probabilities from technicals (not investment advice)."""
from __future__ import annotations

import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

from analysis import add_indicators, build_scenarios, fetch_fundamentals, fetch_ohlcv


SCENARIO_COLORS = {
    "uptrend": "#00b894",
    "pullback": "#fdcb6e",
    "range": "#74b9ff",
    "downtrend": "#d63031",
    "volatile": "#6c5ce7",
}

st.set_page_config(page_title="翌日シナリオ（テクニカル）", layout="wide")
st.title("個別銘柄：翌日の値動きシナリオ（テクニカル + ファンダメンタル）")
st.caption(
    "Yahoo Finance の日足データから移動平均・RSI・MACD・ボリンジャー幅・出来高を用いたルールベースの整理です。"
    " さらにファンダメンタル（PER/PBR/ROE/成長率/財務）を加味した総合判定を表示します。"
    " 確率は相対的な重み（合計100%）であり、将来を保証するものではありません。投資判断は自己責任でお願いします。"
)

col1, col2, col3 = st.columns([2, 1, 1])
with col1:
    raw = st.text_input(
        "銘柄コード（ティッカー）",
        value="7203.T",
        help="日本株は証券コード+.T（例: 7203.T）。米国株は AAPL など。",
    )
with col2:
    period = st.selectbox("取得期間", options=["1mo", "3mo", "6mo", "1y", "2y"], index=2)
with col3:
    run = st.button("チャート取得・分析", type="primary")

ticker = (raw or "").strip().upper()
if run and ticker:
    try:
        with st.spinner("データ取得中..."):
            df = fetch_ohlcv(ticker, period=period)
            try:
                fundamentals = fetch_fundamentals(ticker)
            except Exception:
                fundamentals = {
                    "metrics": {},
                    "reasons_bull": [],
                    "reasons_bear": [],
                    "available": False,
                    "quality_score": 0.0,
                    "stance": "中立",
                }

        if len(df) < 30:
            st.warning("データ本数が少ないため、シナリオ精度は低下しやすいです。可能なら 3mo 以上を推奨します。")

        di = add_indicators(df)
        dplot = di.dropna(subset=["Open", "High", "Low", "Close", "Volume"])
        scenarios, ctx = build_scenarios(df, fundamentals=fundamentals)

        st.markdown(f"## {ticker} 総合見通し - プレゼンテーションビュー")

        fig = make_subplots(
            rows=2,
            cols=1,
            shared_xaxes=True,
            vertical_spacing=0.06,
            row_heights=[0.72, 0.28],
            subplot_titles=("価格", "出来高"),
        )
        fig.add_trace(
            go.Candlestick(
                x=dplot.index,
                open=dplot["Open"],
                high=dplot["High"],
                low=dplot["Low"],
                close=dplot["Close"],
                name="OHLC",
                increasing_line_color="#26a69a",
                decreasing_line_color="#ef5350",
            ),
            row=1,
            col=1,
        )

        ma_lines = [
            (5, "#ff9800", "SMA5"),
            (20, "#2196f3", "SMA20"),
            (30, "#607d8b", "SMA30"),
            (60, "#9c27b0", "SMA60"),
        ]
        for w, color, name in ma_lines:
            colname = f"SMA{w}"
            if colname in dplot.columns and dplot[colname].notna().sum() > 0:
                fig.add_trace(
                    go.Scatter(
                        x=dplot.index,
                        y=dplot[colname],
                        name=name,
                        line=dict(width=1, color=color),
                        opacity=0.9,
                    ),
                    row=1,
                    col=1,
                )

        colors = ["#26a69a" if dplot["Close"].iloc[i] >= dplot["Open"].iloc[i] else "#ef5350" for i in range(len(dplot))]
        fig.add_trace(
            go.Bar(x=dplot.index, y=dplot["Volume"], name="Volume", marker_color=colors, opacity=0.35),
            row=2,
            col=1,
        )
        fig.update_layout(
            xaxis_rangeslider_visible=False,
            height=560,
            legend_orientation="h",
            legend_yanchor="bottom",
            legend_y=1.02,
        )
        fig.update_yaxes(title_text="価格", row=1, col=1)
        fig.update_yaxes(title_text="出来高", row=2, col=1)
        st.plotly_chart(fig, use_container_width=True)

        scen_labels = [s.title_ja for s in scenarios]
        scen_probs = [s.probability_pct for s in scenarios]
        scen_colors = [SCENARIO_COLORS.get(s.key, "#636e72") for s in scenarios]

        cprob, cshare = st.columns([1.35, 1])
        with cprob:
            prob_fig = go.Figure(
                go.Bar(
                    x=scen_probs[::-1],
                    y=scen_labels[::-1],
                    orientation="h",
                    marker_color=scen_colors[::-1],
                    text=[f"{p:.1f}%" for p in scen_probs[::-1]],
                    textposition="outside",
                )
            )
            prob_fig.update_layout(
                title="シナリオ別確率（高い順）",
                xaxis_title="確率(%)",
                yaxis_title="",
                height=360,
                margin=dict(l=8, r=24, t=48, b=20),
            )
            st.plotly_chart(prob_fig, use_container_width=True)

        with cshare:
            pie_fig = go.Figure(
                data=[
                    go.Pie(
                        labels=scen_labels,
                        values=scen_probs,
                        hole=0.55,
                        marker=dict(colors=scen_colors),
                        textinfo="label+percent",
                        sort=False,
                    )
                ]
            )
            pie_fig.update_layout(
                title="シナリオ構成比",
                height=360,
                margin=dict(l=8, r=8, t=48, b=20),
                annotations=[dict(text="Next Day", x=0.5, y=0.5, showarrow=False, font=dict(size=16))],
            )
            st.plotly_chart(pie_fig, use_container_width=True)

        st.subheader("直近の主要指標（最終日）")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("終値", f"{ctx['close']:.2f}")
        c2.metric("RSI(14)", f"{ctx['rsi']:.1f}")
        c3.metric("5日リターン", f"{ctx['ret5_pct']:.2f}%")
        c4.metric("出来高/20日平均", f"{ctx['volume_ratio']:.2f}x")
        st.write(
            f"移動平均: SMA5={ctx['sma5']:.2f} / SMA20={ctx['sma20']:.2f} / "
            f"{ctx['long_ma_name']}={ctx['long_ma_value']:.2f}  "
            f"| 多頭配列: {'はい' if ctx['sma_alignment_bull'] else 'いいえ'}  "
            f"| 空頭配列: {'はい' if ctx['sma_alignment_bear'] else 'いいえ'}"
        )

        st.subheader("ファンダメンタル評価（総合判定）")
        fmetrics = fundamentals.get("metrics", {})
        f1, f2, f3, f4 = st.columns(4)
        f1.metric("PER", "-" if fmetrics.get("trailing_pe") is None else f"{fmetrics['trailing_pe']:.1f}")
        f2.metric("PBR", "-" if fmetrics.get("price_to_book") is None else f"{fmetrics['price_to_book']:.2f}")
        f3.metric("ROE", "-" if fmetrics.get("roe") is None else f"{fmetrics['roe']*100:.1f}%")
        f4.metric(
            "売上成長率",
            "-" if fmetrics.get("revenue_growth") is None else f"{fmetrics['revenue_growth']*100:.1f}%",
        )

        if ctx.get("fundamental_used"):
            fscore = ctx.get("fundamental_quality_score", 0.0)
            stance = ctx.get("fundamental_stance", "中立")
            st.info(f"ファンダメンタル総合スタンス: **{stance}**（スコア {fscore:+.2f}）")

            cfb, cfr = st.columns(2)
            with cfb:
                st.markdown("**ポジティブ要因**")
                pos = ctx.get("fundamental_reasons_bull", [])
                if pos:
                    for r in pos[:4]:
                        st.markdown(f"- {r}")
                else:
                    st.markdown("- 明確な上振れ要因は限定的です。")
            with cfr:
                st.markdown("**ネガティブ要因**")
                neg = ctx.get("fundamental_reasons_bear", [])
                if neg:
                    for r in neg[:4]:
                        st.markdown(f"- {r}")
                else:
                    st.markdown("- 明確な下押し要因は限定的です。")
        else:
            st.warning("この銘柄はファンダメンタル指標の取得が限定的で、総合判定への反映は弱めです。")

        st.subheader("シナリオ別の解説（総合判定）")
        top = scenarios[0]
        st.info(f"最有力シナリオ: **{top.title_ja}（{top.probability_pct:.1f}%）**")

        s1, s2 = st.columns(2)
        for i, sc in enumerate(scenarios):
            box = s1 if i % 2 == 0 else s2
            with box:
                st.markdown(
                    f"### {i+1}. {sc.title_ja}\n"
                    f"<span style='color:{SCENARIO_COLORS.get(sc.key, '#636e72')};font-size:1.2rem;font-weight:700'>{sc.probability_pct:.1f}%</span>",
                    unsafe_allow_html=True,
                )
                st.markdown(f"**想定**: {sc.summary_ja}")
                st.markdown("**根拠**")
                for r in sc.reasons_ja:
                    st.markdown(f"- {r}")

    except Exception as e:
        st.error(str(e))
elif run and not ticker:
    st.warning("銘柄コードを入力してください。")

st.divider()
st.markdown("**免責**: 本アプリは教育・情報整理目的です。特定の金融商品の売買を勧誘するものではありません。")
