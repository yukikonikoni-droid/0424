@echo off
set PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe
if not exist "%PY%" set PY=python
cd /d "%~dp0"
"%PY%" -m streamlit run app.py --server.headless true
pause
